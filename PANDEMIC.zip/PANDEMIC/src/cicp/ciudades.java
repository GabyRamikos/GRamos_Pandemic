package cicp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class ciudades {

	public static void main(String[] args) {

		int lineas;
		File file = new File("ciudades.txt");
		lineas = verLineasFicheroCICP(file);
		guardarCiudades(file, lineas);

	}

	public static int verLineasFicheroCICP(File file) {
		int totalDeLineas = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			while (br.readLine() != null)
				totalDeLineas++;
		} catch (Exception exepcion) {
		}

		return totalDeLineas;

	}

	public static void ciudades(String[][] ciudades) {

		int c, cc, ccc;
		String ciudad;
		String[] cCol;
		String[] c1;
		String[] c2;
		String datos;
		double distanciaEntreCiudades;
		int numCiu;
		int num;
		boolean datosFichero = false;

		datosFichero = comprovarArchivoCiudadesGuardadas();
		if(datosFichero == false) {
		for (c = 0; c < ciudades.length; c++) {
			numCiu = c + 1;
			ciudad = ciudades[c][0];
			c1 = ciudades[c][2].split(",");

			datos = numCiu + "-->" + "La ciudad " + ciudad + " está en las coordenadas " + c1[0] + " , " + c1[1]
					+ " sus ciudades colindates son las siguientes:\n";
			System.out.println(datos);
			
			
				nuevoArchivo(datos);

				cCol = ciudades[c][3].split(",");
	
				for (cc = 0; cc < cCol.length; cc++) {
	
					for (ccc = 0; ccc < ciudades.length; ccc++) {
	
						if (ciudades[ccc][0].equals(cCol[cc])) {
	
							num = cc + 1;
	
							c2 = ciudades[ccc][2].split(",");
	
							distanciaEntreCiudades = calcularDistancia(c1, c2);
	
							datos = (num + "->" + cCol[cc] + " que está a una distancia de " + distanciaEntreCiudades);
							System.out.println(datos);
	
							nuevoArchivo(datos);
						}
	
					}
	
				}
				System.out.println("\n");
			}

		}

	}

	public static void guardarCiudades(File file, int lineas) {
		String linea = " ";
		String[][] ciudades = new String[lineas][];
		int contador = 0;

		try {

			BufferedReader br = new BufferedReader(new FileReader(file));

			do {
				linea = br.readLine();
				if (linea != null) {
					ciudades[contador] = linea.split(";");
					contador++;
				}
			} while (linea != null);

			br.close();
		} catch (Exception exepcion) {
			System.out.println("ERROR: " + exepcion);
		}

		ciudades(ciudades);

	}
	public static boolean comprovarArchivoCiudadesGuardadas() {
		String linea = " ";
		boolean tieneDatos = false;		
		try {

			BufferedReader br = new BufferedReader(new FileReader(("ciudadesRedactadas.txt")));

			linea = br.readLine();
			if (linea == null) {
				tieneDatos = false;
				
			} else {
				tieneDatos = true;
			}
			br.close();
			
			
		} catch (Exception exepcion) {
			System.out.println("ERROR: " + exepcion);
		}
		
		return tieneDatos;
	}


	public static double calcularDistancia(String[] coo1, String[] coo2) {

		int c1 = Integer.parseInt(coo1[0]);
		int cc1 = Integer.parseInt(coo1[1]);
		int c2 = Integer.parseInt(coo2[0]);
		int cc2 = Integer.parseInt(coo2[1]);
		int d1;
		int d2;
		double resultadoDistancia;
		d1 = (cc2 - c2) * (cc2 - c2);
		d2 = (cc1 - c1) * (cc1 - c1);

		resultadoDistancia = Math.sqrt(d1 + d2);

		return resultadoDistancia;
	}

	public static void nuevoArchivo(String frase) {

		File nuevoFicheroDeLaDistanciaDeLasCiudades = new File("ciudadesRedactadas.txt");

		try {

			BufferedWriter bw = new BufferedWriter(new FileWriter(nuevoFicheroDeLaDistanciaDeLasCiudades, true));

			bw.write(frase);
			bw.newLine();

			bw.close();

		} catch (Exception exepcion) {
			System.out.println("ERROR: " + exepcion);
		}

	}

}
